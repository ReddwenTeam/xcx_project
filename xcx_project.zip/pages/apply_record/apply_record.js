
var RECORD_LIST = [
  {
    student_name:"玉鹏",
    status:"已通过",
    grade:"六",
    student_avatar:"../../temp/head.png",
    time:"2017-06-15 16:25:26"
  },
  {
    student_name: "玉鹏",
    status: "未通过",
    grade: "三",
    student_avatar: "../../temp/head.png",
    time: "2017-06-15 16:25:26"
  }
]


Page({

  data: {
    record_list: RECORD_LIST
  },

})